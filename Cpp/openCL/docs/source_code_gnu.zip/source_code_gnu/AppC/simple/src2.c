#include <stdio.h>

void hello2() {
   printf("Hello from src2.c!\n");
}