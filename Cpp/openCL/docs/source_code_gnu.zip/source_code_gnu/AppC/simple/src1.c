#include <stdio.h>

void hello1() {
   printf("Hello from src1.c!\n");
}