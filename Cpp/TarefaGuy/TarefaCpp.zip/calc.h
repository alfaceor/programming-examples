#ifndef CALC_H
#define CALC_H

double Add(double a, double b){
  return a+b;
}

double Substraction(double a, double b){
  return a-b;
}

double Division(double a, double b){
  return a/b;
}

double Multiplication(double a, double b){
  return a*b;
}

#endif /*CALC_H*/
